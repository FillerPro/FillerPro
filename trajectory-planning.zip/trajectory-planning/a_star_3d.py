
# Algoritmo A* para planejamento de trajetoria facial segura (MVP - Ácido Hialurônico)
import heapq

class Node:
    def __init__(self, position, g=0, h=0, parent=None):
        self.position = position  # (x, y, z)
        self.g = g
        self.h = h
        self.f = g + h
        self.parent = parent

    def __lt__(self, other):
        return self.f < other.f

def heuristic(a, b):
    return ((a[0] - b[0])**2 + (a[1] - b[1])**2 + (a[2] - b[2])**2) ** 0.5

def get_neighbors(node, mesh_shape):
    neighbors = []
    directions = [(1,0,0), (-1,0,0), (0,1,0), (0,-1,0), (0,0,1), (0,0,-1)]
    for dx, dy, dz in directions:
        x, y, z = node.position[0] + dx, node.position[1] + dy, node.position[2] + dz
        if 0 <= x < mesh_shape[0] and 0 <= y < mesh_shape[1] and 0 <= z < mesh_shape[2]:
            neighbors.append((x, y, z))
    return neighbors

def a_star(start, goal, risk_map):
    open_list = []
    closed_set = set()

    start_node = Node(start, 0, heuristic(start, goal))
    heapq.heappush(open_list, start_node)

    while open_list:
        current = heapq.heappop(open_list)
        if current.position == goal:
            path = []
            while current:
                path.append(current.position)
                current = current.parent
            return path[::-1]

        closed_set.add(current.position)
        for neighbor_pos in get_neighbors(current, risk_map.shape):
            if neighbor_pos in closed_set or risk_map[neighbor_pos] == 1:
                continue
            g = current.g + heuristic(current.position, neighbor_pos)
            h = heuristic(neighbor_pos, goal)
            neighbor_node = Node(neighbor_pos, g, h, current)
            heapq.heappush(open_list, neighbor_node)

    return None
